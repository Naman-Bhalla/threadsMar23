package com.scaler.lld.machinecoding.tictactoe.models;

public enum BotDifficultyLevel {
    EASY,
    MEDIUM,
    HARD,
}
