package com.scaler.lld.machinecoding.tictactoe.models;

public class Symbol {
    private char aChar;

    public Symbol(char aChar) {
        this.aChar = aChar;
    }

    public char getaChar() {
        return aChar;
    }

    public void setaChar(char aChar) {
        this.aChar = aChar;
    }
}
