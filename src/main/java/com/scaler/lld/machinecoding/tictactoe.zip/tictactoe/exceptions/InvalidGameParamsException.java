package com.scaler.lld.machinecoding.tictactoe.exceptions;

public class InvalidGameParamsException extends Exception {

    public InvalidGameParamsException(String message) {
        super(message);
    }
}
