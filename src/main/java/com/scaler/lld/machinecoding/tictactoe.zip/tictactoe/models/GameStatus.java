package com.scaler.lld.machinecoding.tictactoe.models;

public enum GameStatus {
    IN_PROGRESS,
    ENDED,
    DRAW,
}
